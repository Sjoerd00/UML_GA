INTRODUCTION
============
This file provides details how to use the information  contained
in the Website of the book "Understanding Biplots" 
by Gower JC, Lubbe S and Le Roux NJ;
published by Wiley: Chichester; January 2011.
Corrections as well as bug fixes pertaining to "Understanding Biplots" 
and the R programs will be posted in the section "Corrections". This 
section will be updated on a regular basis. If needed, a FAQ section 
will also be provided with regular updates.

The following files pertain to UBBipl.3.06

1. The file: ReadMe.UBbipl.3.0.6.txt (this file)

2. The R package UBbipl in format: 
                 UBbipl_3.0.6.zip
		 UBbipl_3.0.6.tar.gz
				 
3. A second R package UBFigs in zip format: 
				UBFigs_3.0.5.zip
				UBFigs_3.0.5.tar.gz

								
It is assumed that the reader/user has a basic knowledge of the R system
and has an installed version of R-3.5.0 or higher. We intentionally do 
not provide complete help files as users of UBbipl should consult "Understanding Biplots"
for a full understanding of our R code. 

The packages UBbipl and UBFigs are built under R-3.6.1 and provision 
is made for both 32 and 64 bit machines.

DOWNLOAD AND FIRST TIME USE
===========================
1. First read the file ReadMe.UBbipl.3.0.6.txt

2. Download and save the appropriate version of UBbipl to your computer.
   Then Install the package from within R. 

3. Download and save the appropriate version of UBFigs to your computer
   after UBbipl has been installed.
   Then Install the package from within R.

4. Attach UBbipl and UBFigs on the search path by 
   giving the instructions 
   
   > library(UBbipl)
   > library(UBFigs)
   
   from the R prompt.
 
5. Note that UBbipl can be used on its own but UBFigs depends on
   UBbipl being loaded.

6. It is recommended that first time users give the instructions

   > ?UBbipl
   and
   > ?UBFigs 
   
   from the R prompt to inspect the Index and other information
   regarding the two packages.
   
7. The help files of UBbipl_package and UBFigs_package (see above)
   contain email addresses of the maintainer of the packages and 
   where additional information can be found as well as the reporting
   of bugs.
   
       
Package UBbipl
==============
This package contains all the functions discussed in "Understanding
Biplots". Version 3.0.6 includes several additional functions for 
use with extensions of section 5.8 of Understanding Biplots. Full 
details on the use of these functions are under construction.

Package UBFigs
==============
This package contains the function calls to reproduce the figures in
"Understanding Biplots". Consult "Understanding Biplots" and the help
file index for details about the function calls.

With the exception of Fig.9.9() all functions should complete quite 
quickly -- at most within a few minutes. Function call Fig.9.9()
could take about two or more hours to complete.

3D Figures
==========
We urge users of "Understanding Biplots" to inspect all 3D figures in
the book interactively as follows:

Enter at the R prompt for example

> Fig.3.40()

An rgl window will open with the 3D figure. This graph window can then
interactively be resized, rotated and zoomed for a detailed inspection  
together with quality hard copies as needed.  
------------------------------------------------------------------------  				
John Gower, Sugnet Lubbe and Niel le Roux				