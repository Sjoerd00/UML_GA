my.grad <-
function (func, x, method = "Richardson", side = NULL, 
    method.args = list(), ...) 
{# The function grad.default from package num.deriv
    f <- func(x, ...)
    n <- length(x)
    if (is.null(side)) 
        side <- rep(NA, n)
    else {
        if (n != length(side)) 
            stop("Non-NULL argument 'side' should have the same length as x")
        if (any(1 != abs(side[!is.na(side)]))) 
            stop("Non-NULL argument 'side' should have values NA, +1, or -1.")
    }
    case1or3 <- n == length(f)
    if ((1 != length(f)) & !case1or3) 
        stop("grad assumes a scalar valued function.")
    if (method == "simple") {
        args <- list(eps = 1e-04)
        args[names(method.args)] <- method.args
        side[is.na(side)] <- 1
        eps <- rep(args$eps, n) * side
        if (case1or3) 
            return((func(x + eps, ...) - f)/eps)
        df <- rep(NA, n)
        for (i in 1:n) {
            dx <- x
            dx[i] <- dx[i] + eps[i]
            df[i] <- (func(dx, ...) - f)/eps[i]
        }
        return(df)
    }
    else if (method == "complex") {
        if (any(!is.na(side))) 
            stop("method 'complex' does not support non-NULL argument 'side'.")
        eps <- .Machine$double.eps
        v <- try(func(x + eps * (0+1i), ...))
        if (inherits(v, "try-error")) 
            stop("function does not accept complex argument as required by method 'complex'.")
        if (!is.complex(v)) 
            stop("function does not return a complex value as required by method 'complex'.")
        if (case1or3) 
            return(Im(v)/eps)
        h0 <- rep(0, n)
        g <- rep(NA, n)
        for (i in 1:n) {
            h0[i] <- eps * (0+1i)
            g[i] <- Im(func(x + h0, ...))/eps
            h0[i] <- 0
        }
        return(g)
    }
    else if (method == "Richardson") {
        args <- list(eps = 1e-04, d = 1e-04, zero.tol = sqrt(.Machine$double.eps/7e-07), 
            r = 4, v = 2, show.details = FALSE)
        args[names(method.args)] <- method.args
        d <- args$d
        r <- args$r
        v <- args$v
        show.details <- args$show.details
        a <- matrix(NA, r, n)
        h <- abs(d * x) + args$eps * (abs(x) < args$zero.tol)
        pna <- (side == 1) & !is.na(side)
        mna <- (side == -1) & !is.na(side)
        for (k in 1:r) {
            ph <- mh <- h
            ph[pna] <- 2 * ph[pna]
            ph[mna] <- 0
            mh[mna] <- 2 * mh[mna]
            mh[pna] <- 0
            if (case1or3) 
                a[k, ] <- (func(x + ph, ...) - func(x - mh, ...))/(2 * 
                  h)
            else for (i in 1:n) {
                if ((k != 1) && (abs(a[(k - 1), i]) < 1e-20)) 
                  a[k, i] <- 0
                else a[k, i] <- (func(x + ph * (i == seq(n)), 
                  ...) - func(x - mh * (i == seq(n)), ...))/(2 * 
                  h[i])
            }
            if (any(is.na(a[k, ]))) 
                stop("function returns NA at ", h, " distance from x.")
            h <- h/v
        }
        if (show.details) {
            cat("\n", "first order approximations", 
                "\n")
            print(a, 12)
        }
        for (m in 1:(r - 1)) {
            a <- (a[2:(r + 1 - m), , drop = FALSE] * (4^m) - 
                a[1:(r - m), , drop = FALSE])/(4^m - 1)
            if (show.details & m != (r - 1)) {
                cat("\n", "Richarson improvement group No. ", 
                  m, "\n")
                print(a[1:(r - m), , drop = FALSE], 12)
            }
        }
        return(c(a))
    }
    else stop("indicated method ", method, "not supported.")
}
