MinSpanEllipse <-
function (x, ...) 
UseMethod("MinSpanEllipse")
