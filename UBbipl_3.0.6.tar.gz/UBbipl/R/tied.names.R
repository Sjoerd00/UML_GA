tied.names <-
function (cats = c("a", "b", "c", "d", "e", "f", "g"), vals = c(0.1, 
    0.2, 0.2, 0.3, 0.3, 0.3, 0.4)) 
{# vals constant or monotone increasing(decreasing)
	check.val <- NA
	check <- vals[2: length(vals)]-vals[-length(vals)]
		if(all(check >=0)) check.val <- 'incr'
		if(all(check <=0)) check.val <- 'decr'
		if(all(check ==0)) check.val <- 'const'
	if(is.na(check.val)) stop("vals must be constant or monotone increasing(decreasing)")
if(check.val == 'const') cat.labs <- paste(cats,collapse='*')

unique.points <- table(vals)
k <- length(unique.points)

tel <- 1	
if(check.val == 'incr')
   {cat.labs <- rep(NA, k)    
        for (i in 1:k) {
        if (unique.points[i] == 1) {
            cat.labs[i] <- cats[tel]
            tel <- tel + 1
        }
        else {
            cat.lab.temp <- cats[tel]
            for (j in 1:(unique.points[i] - 1)) {
                cat.lab.temp <- paste(cat.lab.temp, cats[tel + 
                  j], sep = "*")
            }
            cat.labs[i] <- cat.lab.temp
            tel <- tel + cumsum(unique.points[i])
        }
    }
	}
	###############################################
	if(check.val == 'decr')
   { cat.labs <- rep(NA, k)  
   unique.points <- rev(unique.points)
   for (i in 1:k) {
        if (unique.points[i] == 1) {
            cat.labs[i] <- cats[tel]
            tel <- tel + 1
        }
        else {
            cat.lab.temp <- cats[tel]
            for (j in 1:(unique.points[i] - 1)) {
                cat.lab.temp <- paste(cat.lab.temp, cats[tel + 
                  j], sep = "*")
            }
            cat.labs[i] <- cat.lab.temp
            tel <- tel + cumsum(unique.points[i])
        }
    }
	}
    cat.labs
}
